
class PlaybackFailed(Exception):
      '''XBMC falhou a carregar o stream'''

